int NaMe_nAmE1231name() { 
  int x;
  int y;
  int z;
  int a;
  int b;
  int c;
  x = 1.23;
  y = 1.230;
  z = 123e-2;
  a = 123e+02;
  b = 1.23f;
  c = 3.21F;
  return z;
}