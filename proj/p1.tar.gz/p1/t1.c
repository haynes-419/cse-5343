int f() { 
  int x;
  int y;
  int z;
  x = 1;
  y = 2;
  z = x + 8*y;
  return z*z + 1;
}
