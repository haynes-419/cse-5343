int NaMe_nAmE1231name() { 
  int x;
  int y;
  int z;
  x = 1.23;
  y = 1.230;


  z = x + y;
  z = x - y;
  z = x / y;
  z = x * y;
  z = x % y;
  z += y;
  z -= x;
  z /= x;
  z *= x;
  z %= x;

  return z;
}