int f() { 
  int x;
  int y;
  int z;
  x = 036;
  y = 0x45;
  z = x + 8*y;
  return z*z + 1;
}