double g() { int x; int y;
x = 5+ 3; y = x; }