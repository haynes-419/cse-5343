int name_name() { 
  int x;
  int y;
  int z;
  x = 10;
  y = 5;

  z = x + y * z;
  z += 5 - 10;
  z = 12 % 4 - 3 * 5; 

  return z;
}