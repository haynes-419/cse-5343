int f() { 
    int a[1];
    int b[0];

    a = 1 + 1; 
    
    return a; 
}