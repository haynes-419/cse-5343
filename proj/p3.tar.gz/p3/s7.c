int f() { 
    int a[1][5];
    double b;

    b = 10.2; 
    
    return b; 
}