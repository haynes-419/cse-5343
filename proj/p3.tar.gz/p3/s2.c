int f() { 
    int a;
    int a;

    a = 1 + 1; 
    
    return a; 
}