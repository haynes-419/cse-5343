int f() { 
    int a[1][5];
    int b[10];

    a[1][5] + b[1] = 1 + 1; 
    
    return a; 
}