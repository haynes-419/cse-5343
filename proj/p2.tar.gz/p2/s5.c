int f() {
    double E;
    double alpha[16];
    int m;

    for (m = 2; m < 16 >= E == 10; m=m+1) {
        E = E + 1;
    }

    while (E < 10 <= 15 >= 5 > 1){
        E = E + 1;
    }

    for (m = 2; m != 16 >= E == 10; m=m+1) {
        E = E + 1;
    }

    while (E != 10 <= 15 != 12 >= 5){
        E = E + 1;
    }
}