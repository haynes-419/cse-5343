int f() {
    int x;
    int y;

    x = 1;
    y = 0;

    while(x < 5){
        x = x + 1;
    }

    for(x; x < 10; x += 1){
        y += 1;
    }
}