int f() {
    int x;

    while(x) {
        x = x + 1;
    }

    for(x; x; x) {
        x = x + 1;
    }
}