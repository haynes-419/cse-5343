double s5() {
    int a[10][20];
    int b[19];
    int m;
    
    for (m = 4; m < 64; m=m+1){
        a[10 + 6][5 + 3] = b[10];
    }
    
}