int s3() {int n; int i; int res;
    n = 10;
    i = 1;
    res = 1;
    while (i <= n) {
        res *= i;
        i += 1;
    }
}