#include <stdio.h> 
int f3(void); int main(void) { int res = f3(); printf("%d\n",res); }