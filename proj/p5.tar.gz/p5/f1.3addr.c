int f1()
{
  int x;
  int y;
  int _t1;
x=1;
_t1=x>2;
if (!_t1) goto _l2;
return 3;
goto _l1;
_l2:
y=4;
return y;
_l1:
;
}
