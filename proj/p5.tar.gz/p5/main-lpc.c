#include <stdio.h> 
double lpc(void); 
int main(void) { double res = lpc(); printf("%lf\n",res); }