double s1() {
    int x; int y; int z;
    x = 1;
    y = 2;
    z = 3;
    if (x+y > z) z=x+y;
}