int e6() {
    int x;
    int y;
    x = 1;
    y = 2;
    if (x < y) return x;
    else return y;
}