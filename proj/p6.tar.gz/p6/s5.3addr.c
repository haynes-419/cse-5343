double s5()
{
  int _t6;
  int a[10][20];
  int _t5;
  int b[19];
  int _t2;
  int m;
  int _t1;
  int _t4;
  int _t3;
m=4;
_l1:
_t1=m<64;
if (! _t1) goto _l2;
_t2=10+6;
_t3=5+3;
a[_t2][_t3]=b[10];
_t6=m+1;
m=_t6;
goto _l1;
_l2:
return m;
}
