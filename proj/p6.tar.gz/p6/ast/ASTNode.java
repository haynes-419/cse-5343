package ast;
import java.io.PrintStream;

abstract class ASTNode {
}
