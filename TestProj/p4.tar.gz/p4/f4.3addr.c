int f4()
{
  int x;
  int y;
  int z;
  int _t2;
  int _t1;
x=1;
y=2;
z=3;
_t1=y*z;
_t2=x-_t1;
return _t2;
}
