int f2() {int x; int y; int z;
    x = 1;
    z = (x += 1) + (y += x+2);  }