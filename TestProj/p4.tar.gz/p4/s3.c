int f2() {int a[10][20];
    int x; int y; int z;
    x = 1;
    y = 2;
    z = 3;
    a[y-x][y+x] = z + 2*y; }