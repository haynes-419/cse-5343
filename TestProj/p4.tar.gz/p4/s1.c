double f() {
    int x;
    int y;
    
    x = 1 + 2;

    x += 2;

    return x;
}