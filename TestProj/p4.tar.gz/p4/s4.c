double s4() {
    int a[10][20];
    int x; int y; int z;
    double w;
    x = 1;
    y = 2;
    z = 3;
    w = 2 + 2.2;
    a[y-x][y+x] = z + 2*y; 
    return w;
}