int f6()
{
  int a[2][3];
  int x;
  int _t2;
  int _t1;
  int _t4;
  int _t3;
x=1;
_t1=x+2;
_t3=x+1;
a[x][_t3]=_t1;
return a[1][2];
}
