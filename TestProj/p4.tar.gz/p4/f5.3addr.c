int f5()
{
  int _t6;
  int _t5;
  int w;
  int x;
  int y;
  int z;
  int _t2;
  int _t1;
  int _t4;
  int _t3;
x=11;
_t1=x+1;
x=_t1;
_t2=x+2;
y=_t2;
_t3=_t1+_t2;
z=_t3;
w=_t3;
_t4=x+y;
_t5=_t4+z;
_t6=_t5+w;
return _t6;
}
